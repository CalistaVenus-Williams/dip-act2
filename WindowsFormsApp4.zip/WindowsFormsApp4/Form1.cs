﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebCamLib;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        Bitmap loaded, result;
        Bitmap imageM, imageBG;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            loaded = new Bitmap(openFileDialog1.FileName);
            pictureBox1.Image= loaded;
            result = new Bitmap(loaded.Width, loaded.Height);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            for(int x=0; x<loaded.Width; x++)
            {
                for(int y=0; y<loaded.Height; y++)
                {
                    pixel=loaded.GetPixel(x, y);
                    result.SetPixel(x, y, pixel);
                }
            } pictureBox2.Image = result;

        }

        private void greyscaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            int grey;
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    grey = (byte)((pixel.R+pixel.G+pixel.B)/3);
                    result.SetPixel(x, y, Color.FromArgb(grey, grey, grey));
                }
            }
            pictureBox2.Image = result;
        }

        private void colorInversionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    result.SetPixel(x, y, Color.FromArgb(255-pixel.R, 255-pixel.G, 255-pixel.B));
                }
            }
            pictureBox2.Image = result;
        }

        private void histogramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            int grey;
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    grey = (byte)((pixel.R + pixel.G + pixel.B) / 3);
                    result.SetPixel(x, y, Color.FromArgb(grey, grey, grey));
                }
            }
            Color sample;
            int[] histo = new int[256];
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    sample = result.GetPixel(x, y);
                    histo[sample.R] = histo[sample.R] + 1;
                }
            }
            Bitmap grph = new Bitmap(256,550);
            for(int x = 0; x < 256; x++)
            {
                for (int y = 0; y < 550; y++)
                {
                    grph.SetPixel(x, y, Color.White);
                }
            }
            for (int x = 0; x < 256; x++)
            {
                for (int y = 0; y < Math.Min(histo[x] / 10, 550); y++)
                {
                    grph.SetPixel(x, 549-y, Color.Black);
                }
            }
            pictureBox2.Image = grph;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog(this);
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            result.Save(saveFileDialog1.FileName);
        }

        private void sepiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    int rval = (int)(pixel.R * 0.393 + pixel.G * 0.769 + pixel.B * 0.189);
                    int gval = (int)(pixel.R * 0.349 + pixel.G * 0.686 + pixel.B * 0.168);
                    int bval = (int)(pixel.R * 0.272 + pixel.G * 0.534 + pixel.B * 0.131);
                    result.SetPixel(x, y, Color.FromArgb(Math.Min(255,rval),Math.Min(255, gval),Math.Min(255,bval)));
                }
            }
            pictureBox2.Image = result;
        }

        private void subractionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color mygreen = Color.FromArgb(0, 0, 255);
            int greygreen =(int)(mygreen.R + mygreen.G + mygreen.B)/3;
            int threshold = 15;

            for(int x = 0; x<loaded.Width; x++)
            {
                for(int y = 0; y<loaded.Height; y++)
                {
                    Color pixel = loaded.GetPixel(x, y);
                    Color backpixel = imageBG.GetPixel(x, y);
                    int grey = (int)(pixel.R+pixel.G+pixel.B)/3;
                    int subtractvalue = (int)Math.Abs(greygreen - grey);
                    if(subtractvalue < threshold)
                    {
                        result.SetPixel(x, y, backpixel);
                    } else
                    {
                        result.SetPixel(x, y, pixel);
                    }
                }
            } pictureBox3.Image = result;
        }

        private void loadImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {
            //
        }

        private void openFileDialog3_FileOk(object sender, CancelEventArgs e)
        {
            imageBG = new Bitmap(openFileDialog3.FileName);
            pictureBox2.Image = imageBG;
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            //man idk how to make this work 
            IDataObject data;
            Image bmap;
            DeviceManager.GetAllDevices();
            Device d = DeviceManager.GetDevice(0);
            d.Sendmessage();
            data = Clipboard.GetDataObject();
            bmap = (Image)(data.GetData("System.Drawing.Bitmap", true));
            loaded = new Bitmap(bmap);
        }

        private void loadBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog3.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
